﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswordGen
{
    class Generator
    {
        public void Start()
        {
            string userInput = "y";
            int charNumber;
            int upperBound;

            Random randomiser = new Random();

             Console.Write("Please enter the length you want your password to be (between 8 and 16): ");
             userInput = Console.ReadLine();

             while (!int.TryParse(userInput, out upperBound) || upperBound < 8 || upperBound > 16)
             {
                 Console.Write("Please enter a valid number: ");
                 userInput = Console.ReadLine();
             }
             

            do
            {
                for (int i = 1; i <= upperBound; i++)
                {

                    charNumber = randomiser.Next(33, 126);
                    Console.Write(Convert.ToChar(charNumber));
                }

                Console.WriteLine();
                Console.WriteLine();
                Console.Write("Would you like a different password? ");
                userInput = Console.ReadLine();
                if (userInput == "Y" || userInput == "y")
                {
                    Console.Clear();
                }
            }
            while (userInput == "Y" || userInput == "y");


        }
    }
}
